from project.motorcycle import Motorcycle


class RaceMotorcycle(Motorcycle):
    pass