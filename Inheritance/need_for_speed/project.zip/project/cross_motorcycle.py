from project.motorcycle import Motorcycle

class CrossMotorcycle(Motorcycle):
    DEFAULT_FUEL_CONSUMPTION = 8
