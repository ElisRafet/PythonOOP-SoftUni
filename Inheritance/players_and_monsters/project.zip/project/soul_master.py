from project.wizard import Wizard
class SoulMaster(Wizard):
    def __init__(self, username, level):
        super().__init__(username, level)